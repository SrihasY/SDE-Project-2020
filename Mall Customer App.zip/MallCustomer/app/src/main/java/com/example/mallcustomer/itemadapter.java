package com.example.mallcustomer;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;


import org.w3c.dom.Text;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Vector;



public class itemadapter extends RecyclerView.Adapter<itemadapter.ViewHolder> {
    Vector<item> items;
    Context context;
    String storename;
    public itemadapter(Vector<item> items,Context context, String storename) {
        this.items = items;
        this.context=context;
        this.storename=storename;
    }

    public void updateList(Vector<item> list){
        items = list;
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.storeitem, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final item current = items.get(position);
        holder.id.setText(current.id);
        holder.name.setText(current.name);
        if (current.stock.equals("0")) {
            holder.stock.setTextColor(Color.RED);
            holder.stock.setText("OUT OF STOCK");
        } else {
            holder.stock.setTextColor(Color.GREEN);
            holder.stock.setText("IN STOCK");
        }
        final String stockstat= holder.stock.getText().toString();
        holder.lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(stockstat.equals("OUT OF STOCK"))
                {
                    AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext(), R.style.Theme_MaterialComponents_Dialog);
                    ViewGroup viewGroup = view.findViewById(android.R.id.content);
                    final View dialogView = LayoutInflater.from(view.getContext()).inflate(R.layout.itemreq, viewGroup, false);
                    builder.setView(dialogView);
                    TextView dialogtext = dialogView.findViewById(R.id.dialogtext);
                    dialogtext.setText("The item \""+current.name+"\" selected is out of stock at the store \""+storename+"\". Do you wish to make an item request?");
                    final AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                    dialogView.findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            alertDialog.dismiss();
                        }
                    });
                    dialogView.findViewById(R.id.newireq).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(final View v) {
                            final mallcustomer user = new mallcustomer();
                            user.getdetails(v.getContext());
                            class newreq extends AsyncTask<Void, Void, String> {
                                String result;
                                private String check;
                                TextView create = dialogView.findViewById(R.id.createreq);
                                @Override
                                protected String doInBackground(Void... voids) {
                                    StringBuilder sb = new StringBuilder();
                                    String reqname = "Item Request - "+ current.id;
                                    String reqdesc = "The item (ID: " + current.id + " Name: "+ current.name +") is out of stock. Please restock and update this request accordingly.";
                                    try {
                                        URL url = new URL("http://"+ip.val+":8080/test/AppAddRequest");
                                        HttpURLConnection con = (HttpURLConnection) url.openConnection();
                                        con.setRequestMethod("POST");
                                        con.setDoInput(true);
                                        con.setDoOutput(true);
                                        con.setRequestProperty("Content-Type", "text/plain;charset=UTF-8");
                                        con.setRequestProperty("reqname", reqname);
                                        con.setRequestProperty("reqdesc", reqdesc);
                                        con.setRequestProperty("reqstore", storename);
                                        con.setRequestProperty("customer", user.username);
                                        con.connect();
                                        if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
                                            check = con.getHeaderField("success");
                                        }
                                        con.disconnect();
                                    } catch (MalformedURLException ex) {
                                        ex.printStackTrace();
                                    } catch (IOException ex) {
                                        ex.printStackTrace();
                                    }
                                    return check;
                                }

                                @Override
                                protected void onPostExecute(String check) {
                                    if (check != null) {
                                        if (check.equals("new")) {
                                            int duration = Toast.LENGTH_LONG;
                                            Toast.makeText(create.getContext(), "Request created.", duration).show();
                                            alertDialog.dismiss();
                                        } else if (check.equals("repeat")) {
                                            int duration = Toast.LENGTH_LONG;
                                            Toast.makeText(create.getContext(), "The request already exists.", duration).show();
                                        }
                                    }
                                    else {
                                        int duration = Toast.LENGTH_SHORT;
                                        Toast.makeText(create.getContext(), "No Server Response", duration).show();
                                    }
                                }
                            }
                            new newreq().execute();
                        }
                    });

                }
            }
        });
    }


    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView id;
        public TextView name;
        public TextView stock;
        public ConstraintLayout lay;
        public ViewHolder(View itemView) {
            super(itemView);
            this.id = itemView.findViewById(R.id.itemid);
            this.name = itemView.findViewById(R.id.itemname);
            this.stock = itemView.findViewById(R.id.stock);
            this.lay = itemView.findViewById(R.id.storeitemlay);
        }
    }
}