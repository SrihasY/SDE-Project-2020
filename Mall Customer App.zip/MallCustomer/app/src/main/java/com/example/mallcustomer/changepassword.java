package com.example.mallcustomer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class changepassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_changepassword);
        Button change = findViewById(R.id.passbutton);

        change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText oldpass = findViewById(R.id.currentpass);
                final String oldpassword = oldpass.getText().toString();
                final mallcustomer current = new mallcustomer();
                current.getdetails(getApplicationContext());
                if (current.password.equals(oldpassword)) {
                    class pass extends AsyncTask<Void, Void, String> {
                        String result;
                        private String check;
                        EditText newpass = findViewById(R.id.newpass);
                        String newpassword = newpass.getText().toString();
                        @Override
                        protected String doInBackground(Void... voids) {
                            StringBuilder sb = new StringBuilder();
                            try {
                                URL url = new URL("http://"+ip.val+":8080/test/AppChangePassword");
                                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                                con.setRequestMethod("POST");
                                con.setDoInput(true);
                                con.setDoOutput(true);
                                con.setRequestProperty("Content-Type", "text/plain;charset=UTF-8");
                                con.setRequestProperty("username", current.username);
                                con.setRequestProperty("currentpassword", oldpassword);
                                con.setRequestProperty("newpassword", newpassword);
                                if (oldpassword == null || newpass == null) {
                                    return "blank";
                                }
                                con.connect();
                                if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
                                    check = con.getHeaderField("success");
                                }
                                con.disconnect();
                            } catch (MalformedURLException ex) {
                                ex.printStackTrace();
                            } catch (IOException ex) {
                                ex.printStackTrace();
                            }
                            return check;
                        }

                        @Override
                        protected void onPostExecute(String sb) {
                            if (check != null) {
                                if (check.equals("new")) {
                                    int duration = Toast.LENGTH_LONG;
                                    Toast.makeText(oldpass.getContext(), "Password changed", duration).show();
                                    try {
                                        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(getApplicationContext().openFileOutput("userdata.txt", Context.MODE_PRIVATE));
                                        outputStreamWriter.write(current.username+'\n');
                                        outputStreamWriter.write(newpassword);
                                        outputStreamWriter.close();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    finish();
                                } else if (check.equals("blank")) {
                                    int duration = Toast.LENGTH_SHORT;
                                    Toast.makeText(oldpass.getContext(), "Please fill in all the fields", duration).show();
                                } else if (check.equals("wrong")) {
                                    int duration = Toast.LENGTH_LONG;
                                    Toast.makeText(oldpass.getContext(), "Current password incorrect", duration).show();
                                }
                            } else {
                                int duration = Toast.LENGTH_SHORT;
                                Toast.makeText(oldpass.getContext(), "No Server Response", duration).show();
                            }
                        }
                    }
                    new pass().execute();
                } else {
                    int duration = Toast.LENGTH_SHORT;
                    Toast.makeText(oldpass.getContext(), "Incorrect details entered.", duration).show();
                }
            }
        });
    }
}

