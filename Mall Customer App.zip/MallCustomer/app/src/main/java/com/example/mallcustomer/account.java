package com.example.mallcustomer;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;



import java.io.IOException;
import java.io.OutputStreamWriter;

public class account extends Fragment {
    public static account newInstance() {
        account fragment = new account();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_account, container, false);
    }

    @Override
    public void onViewCreated(@NonNull final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mallcustomer current = new mallcustomer();
        current.getdetails(view.getContext());
        TextView account = view.findViewById(R.id.account);
        account.setText("Hello, " + current.username);
        TextView change = view.findViewById(R.id.changepass);
        change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent open = new Intent(view.getContext(), changepassword.class);
                startActivity(open);
            }
        });
        TextView logout = view.findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(v.getContext().openFileOutput("userdata.txt", Context.MODE_PRIVATE));
                    outputStreamWriter.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                int duration = Toast.LENGTH_SHORT;
                Toast.makeText(view.getContext(), "You have been logged out.", duration).show();
                Intent open = new Intent(view.getContext(), Login.class);
                startActivity(open);
            }
        });
        TextView events = view.findViewById(R.id.eventbutton);
        events.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent event = new Intent(view.getContext(), events.class);
                startActivity(event);
            }
        });
    }
}