package com.example.mallcustomer;

public class request {
    protected String id,name, status, description, store;


    public request(String id, String name, String status, String description, String store)
    {
        this.id=id;
        this.name=name;
        this.status=status;
        this.description=description;
        this.store=store;
    }

}
