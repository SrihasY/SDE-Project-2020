package com.example.mallcustomer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


public class register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        final Button register2 = findViewById(R.id.register2);
        register2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                class signup extends AsyncTask<Void, Void, String> {
                    String result;
                    private String check;
                    EditText user = findViewById(R.id.userreg);
                    EditText pass = findViewById(R.id.passwordreg);
                    EditText e= findViewById(R.id.emailreg);
                    String username= user.getText().toString();
                    String password= pass.getText().toString();
                    String email= e.getText().toString();

                    @Override
                    protected String doInBackground(Void... voids) {
                        StringBuilder sb = new StringBuilder();
                        try {
                            URL url = new URL("http://"+ip.val+":8080/test/AppSignupResponse");
                            HttpURLConnection con = (HttpURLConnection) url.openConnection();
                            con.setRequestMethod("POST");
                            con.setDoInput(true);
                            con.setDoOutput(true);
                            con.setRequestProperty("Content-Type", "text/plain;charset=UTF-8");
                            con.setRequestProperty("username", username);
                            con.setRequestProperty("password", password);
                            con.setRequestProperty("email", email);
                            if(username==null || password==null || email==null)
                            {
                                return "blank";
                            }
                            con.connect();
                            if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
                                check = con.getHeaderField("success");
                            }
                            con.disconnect();
                        } catch (MalformedURLException ex) {
                            ex.printStackTrace();
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                        return check;
                    }

                    @Override
                    protected void onPostExecute(String sb) {
                        if (check != null) {
                            if (check.equals("new")) {
                                int duration = Toast.LENGTH_LONG;
                                Toast.makeText(register2.getContext(), "Sign-up successful!", duration).show();
                                Intent open = new Intent(register2.getContext(), Login.class);
                                startActivity(open);
                            } else if (check.equals("blank")) {
                                int duration = Toast.LENGTH_SHORT;
                                Toast.makeText(register2.getContext(), "Please fill in all the fields", duration).show();
                            } else if (check.equals("repeat")) {
                                int duration = Toast.LENGTH_LONG;
                                Toast.makeText(register2.getContext(), "An account already exists with that username/email", duration).show();
                            }
                        }
                        else {
                            int duration = Toast.LENGTH_SHORT;
                            Toast.makeText(register2.getContext(), "No Server Response", duration).show();
                        }
                    }
                }
                new signup().execute();
            }
        });

    }
}
