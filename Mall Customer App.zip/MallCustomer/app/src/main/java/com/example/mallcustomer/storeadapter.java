package com.example.mallcustomer;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;


import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.Vector;



public class storeadapter extends RecyclerView.Adapter<storeadapter.ViewHolder> {
    Vector<store> stores;
    Context context;
    public storeadapter(Vector<store> stores,Context context) {
        this.stores = stores;
        this.context=context;
    }

    public void updateList(Vector<store> list){
        stores = list;
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.item, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final store current = stores.get(position);
        holder.store_name.setText(current.name);
        holder.level.setText("Level:"+current.level);
        holder.lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BottomSheetDialogFragment bottomSheetDialogFragment = new storeinfo(stores.get(position));
                bottomSheetDialogFragment.show(((FragmentActivity)context).getSupportFragmentManager(), bottomSheetDialogFragment.getTag());
            }
        });

        Context context=holder.favorite.getContext();
        final mallcustomer checker = new mallcustomer();
        boolean flag=checker.favcheck(context,stores.get(position));
        if(flag){
            ImageView set=holder.favorite.findViewById(R.id.fav);
            set.setImageResource(R.drawable.favoritefill);
        } else {
            ImageView set=holder.favorite.findViewById(R.id.fav);
            set.setImageResource(R.drawable.favorite);
        }

        holder.favorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean flag=checker.favupdate(v.getContext(),stores.get(position));
                if(flag){
                    ImageView set=v.findViewById(R.id.fav);
                    set.setImageResource(R.drawable.favorite);
                } else {
                    ImageView set=v.findViewById(R.id.fav);
                    set.setImageResource(R.drawable.favoritefill);
                }

            }
        });
    }


    @Override
    public int getItemCount() {
        return stores.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView level;
        public TextView store_name;
        public ImageButton favorite;
        public ConstraintLayout lay;
        public ViewHolder(View itemView) {
            super(itemView);
            this.level = itemView.findViewById(R.id.level);
            this.store_name = itemView.findViewById(R.id.store_name);
            this.lay = itemView.findViewById(R.id.itemlayout);
            this.favorite = itemView.findViewById(R.id.fav);
        }
    }
}