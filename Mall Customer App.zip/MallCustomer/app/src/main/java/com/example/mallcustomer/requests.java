package com.example.mallcustomer;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;

import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Vector;

public class requests extends Fragment {
    public static requests newInstance() {
        requests fragment = new requests();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_requests, container, false);
    }

    public void onViewCreated(@NonNull final View v, Bundle savedInstanceState) {
        super.onViewCreated(v, savedInstanceState);
        final mallcustomer current = new mallcustomer();
        current.getdetails(v.getContext());
        class reqfetch extends AsyncTask<Void, Void, String> {
            String result;
            private String check;
            @Override
            protected String doInBackground(Void... voids) {
                StringBuilder sb = new StringBuilder();
                try {

                    URL url = new URL("http://"+ip.val+":8080/test/AppRequests");
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("POST");
                    con.setDoInput(true);
                    con.setDoOutput(true);
                    con.setRequestProperty("Content-Type", "text/plain;charset=UTF-8");
                    con.setRequestProperty("username", current.username);
                    con.connect();
                    if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        check = con.getHeaderField("success");
                        BufferedReader in = new BufferedReader(
                                new InputStreamReader(
                                        con.getInputStream()));
                        String str;
                        while ((str = in.readLine()) != null) {
                            sb.append(str);
                        }
                    }
                    con.disconnect();
                } catch (MalformedURLException ex) {
                    ex.printStackTrace();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                return sb.toString();
            }

            @Override
            protected void onPostExecute(String sb) {
                if (check != null) {
                    if (check.equals("true")) {
                        final Vector<request> requests = new Vector<request>();
                        JSONArray reqarray = null;
                        try {
                            reqarray = new JSONArray(sb);
                            for (int i = 0; i < reqarray.length(); i++) {
                                JSONObject current = reqarray.getJSONObject(i);

                                request newreq = new request(current.getString("id"),current.getString("name"), current.getString("status"), current.getString("description"), current.getString("store"));
                                requests.add(newreq);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        int resId = R.anim.layoutfall;
                        LinearLayoutManager man = new LinearLayoutManager(v.getContext());
                        RecyclerView recyclerView = v.findViewById(R.id.reqrecycle);
                        DividerItemDecoration div = new DividerItemDecoration(recyclerView.getContext(),
                                man.getOrientation());
                        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(v.getContext(), resId);
                        recyclerView.setLayoutAnimation(animation);
                        recyclerView.addItemDecoration(div);
                        final reqadapter adapter = new reqadapter(requests,v.getContext());
                        recyclerView.setHasFixedSize(true);
                        recyclerView.setLayoutManager(man);
                        recyclerView.setAdapter(adapter);
                    } else if (check.equals("false")) {
                        int duration = Toast.LENGTH_LONG;
                        Toast.makeText(v.getContext(), "Server Response Empty", duration).show();
                    }
                } else {
                    int duration = Toast.LENGTH_LONG;
                    Toast.makeText(v.getContext(), "No Server Response", duration).show();
                }
            }
        }
        new reqfetch().execute();
        ImageButton add = v.findViewById(R.id.add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View reqfrag) {
                AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext(), R.style.Theme_MaterialComponents_Dialog);
                ViewGroup viewGroup = v.findViewById(android.R.id.content);
                final View dialogView = LayoutInflater.from(v.getContext()).inflate(R.layout.addreq, viewGroup, false);
                builder.setView(dialogView);
                class storefetch extends AsyncTask<Void, Void, String> {
                    String result;
                    private String check;

                    @Override
                    protected String doInBackground(Void... voids) {
                        StringBuilder sb = new StringBuilder();
                        try {
                            URL url = new URL("http://"+ip.val+":8080/test/AppStoreSearch");
                            HttpURLConnection con = (HttpURLConnection) url.openConnection();
                            con.setRequestMethod("POST");
                            con.setDoInput(true);
                            con.setDoOutput(true);
                            con.setRequestProperty("Content-Type", "text/plain;charset=UTF-8");
                            con.connect();
                            if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
                                check = con.getHeaderField("success");
                                BufferedReader in = new BufferedReader(
                                        new InputStreamReader(
                                                con.getInputStream()));
                                String str;
                                while ((str = in.readLine()) != null) {
                                    sb.append(str);
                                }
                            }
                            con.disconnect();
                        } catch (MalformedURLException ex) {
                            ex.printStackTrace();
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                        return sb.toString();
                    }

                    @Override
                    protected void onPostExecute(String sb) {
                        if (check != null) {
                            if (check.equals("true")) {
                                final Vector<store> stores = new Vector<store>();
                                JSONArray storearray = null;
                                try {
                                    storearray = new JSONArray(sb);
                                    for (int i = 0; i < storearray.length(); i++) {
                                        JSONObject current = storearray.getJSONObject(i);
                                        store newstore = new store(current.getString("name"), current.getString("timings"), current.getString("level"), current.getString("contacts"));
                                        stores.add(newstore);
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                Spinner spinner = dialogView.findViewById(R.id.newreqspin);
                                ArrayList<store> storelist= new ArrayList<store>(stores);
                                ArrayAdapter<store> adapter = new ArrayAdapter<store>(dialogView.getContext(),
                                        android.R.layout.simple_spinner_item, storelist);
                                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                spinner.setAdapter(adapter);

                                spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                    @Override
                                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                                    }
                                    @Override
                                    public void onNothingSelected(AdapterView<?> parent) {

                                    }
                                });

                            } else if (check.equals("false")) {
                                int duration = Toast.LENGTH_LONG;
                                Toast.makeText(getContext(), "Server Response Empty", duration).show();
                            }
                        } else {
                            int duration = Toast.LENGTH_LONG;
                            Toast.makeText(v.getContext(), "No Server Response", duration).show();
                        }
                    }
                }
                new storefetch().execute();
                final AlertDialog alertDialog = builder.create();
                alertDialog.show();
                dialogView.findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.dismiss();
                    }
                });
                final mallcustomer current = new mallcustomer();
                current.getdetails(v.getContext());
                dialogView.findViewById(R.id.add).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(final View v) {
                        class newreq extends AsyncTask<Void, Void, String> {
                            String result;
                            private String check;
                            EditText rname = dialogView.findViewById(R.id.newrname);
                            EditText rdesc = dialogView.findViewById(R.id.desc);
                            Spinner store = dialogView.findViewById(R.id.newreqspin);
                            String reqstore = store.getSelectedItem().toString();

                            String reqname= rname.getText().toString();
                            String reqdesc= rdesc.getText().toString();
                            @Override
                            protected String doInBackground(Void... voids) {
                                StringBuilder sb = new StringBuilder();
                                try {
                                    URL url = new URL("http://"+ip.val+":8080/test/AppAddRequest");
                                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                                    con.setRequestMethod("POST");
                                    con.setDoInput(true);
                                    con.setDoOutput(true);
                                    con.setRequestProperty("Content-Type", "text/plain;charset=UTF-8");
                                    con.setRequestProperty("reqname", reqname);
                                    con.setRequestProperty("reqdesc", reqdesc);
                                    con.setRequestProperty("reqstore", reqstore);
                                    con.setRequestProperty("customer", current.username);
                                    if(TextUtils.isEmpty(reqname) || TextUtils.isEmpty(reqdesc) ||TextUtils.isEmpty(reqstore))
                                    {
                                        return "blank";
                                    }
                                    con.connect();
                                    if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
                                        check = con.getHeaderField("success");
                                    }
                                    con.disconnect();
                                } catch (MalformedURLException ex) {
                                    ex.printStackTrace();
                                } catch (IOException ex) {
                                    ex.printStackTrace();
                                }
                                return check;
                            }

                            @Override
                            protected void onPostExecute(String check) {
                                if (check != null) {
                                    if (check.equals("new")) {
                                        int duration = Toast.LENGTH_LONG;
                                        Toast.makeText(rname.getContext(), "Request created.", duration).show();
                                        alertDialog.dismiss();
                                    } else if (check.equals("blank")) {
                                        int duration = Toast.LENGTH_SHORT;
                                        Toast.makeText(rname.getContext(), "Please fill in all the fields", duration).show();
                                    } else if (check.equals("repeat")) {
                                        int duration = Toast.LENGTH_LONG;
                                        Toast.makeText(rname.getContext(), "The request already exists.", duration).show();
                                    }
                                }
                                else {
                                    int duration = Toast.LENGTH_SHORT;
                                    Toast.makeText(rname.getContext(), "No Server Response", duration).show();
                                }
                            }
                        }
                        new newreq().execute();
                    }
                });
            }
        });
    }
}
