package com.example.mallcustomer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Vector;

public class events extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);
        class eventfetch extends AsyncTask<Void, Void, String> {
            private String check;

            @Override
            protected String doInBackground(Void... voids) {
                StringBuilder sb = new StringBuilder();
                try {
                    URL url = new URL("http://"+ip.val+":8080/test/AppEvents");
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("POST");
                    con.setDoInput(true);
                    con.setDoOutput(true);
                    con.setRequestProperty("Content-Type", "text/plain;charset=UTF-8");
                    con.connect();
                    if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        check = con.getHeaderField("success");
                        BufferedReader in = new BufferedReader(
                                new InputStreamReader(
                                        con.getInputStream()));
                        String str;
                        while ((str = in.readLine()) != null) {
                            sb.append(str);
                        }
                    }
                    con.disconnect();
                } catch (MalformedURLException ex) {
                    ex.printStackTrace();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                return sb.toString();
            }

            @Override
            protected void onPostExecute(String sb) {
                if (check != null) {
                    if (check.equals("true")) {
                        final Vector<event> events = new Vector<event>();
                        JSONArray storearray = null;
                        try {
                            storearray = new JSONArray(sb);
                            for (int i = 0; i < storearray.length(); i++) {
                                JSONObject current = storearray.getJSONObject(i);
                                event newevent = new event(current.getString("id"), current.getString("name"), current.getString("desc"),current.getString("datetime"), current.getString("venue"),current.getString("end"));
                                events.add(newevent);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        int resId = R.anim.layoutfall;
                        LinearLayoutManager man = new LinearLayoutManager(getBaseContext());
                        RecyclerView recyclerView = findViewById(R.id.eventrecycle);
                        DividerItemDecoration div = new DividerItemDecoration(recyclerView.getContext(),
                                man.getOrientation());
                        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(recyclerView.getContext(), resId);
                        recyclerView.setLayoutAnimation(animation);
                        recyclerView.addItemDecoration(div);
                        final eventadapter adapter = new eventadapter(events,recyclerView.getContext());
                        recyclerView.setHasFixedSize(true);
                        recyclerView.setLayoutManager(man);
                        recyclerView.setAdapter(adapter);
                    } else if (check.equals("false")) {
                        int duration = Toast.LENGTH_LONG;
                        Toast.makeText(getApplicationContext(), "Server Response Empty", duration).show();
                    }
                } else {
                    int duration = Toast.LENGTH_LONG;
                    Toast.makeText(getApplicationContext(), "No Server Response", duration).show();
                }
            }
        }
        new eventfetch().execute();
    }
}
