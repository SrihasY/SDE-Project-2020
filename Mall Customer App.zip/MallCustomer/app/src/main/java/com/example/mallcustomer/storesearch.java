package com.example.mallcustomer;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Vector;

public class storesearch extends Fragment {
    public static storesearch newInstance() {
        storesearch fragment = new storesearch();
        return fragment;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_storesearch, container, false);
    }

    public void onViewCreated(@NonNull final View v, Bundle savedInstanceState) {
        super.onViewCreated(v, savedInstanceState);
        class storefetch extends AsyncTask<Void, Void, String> {
            String result;
            private String check;

            @Override
            protected String doInBackground(Void... voids) {
                StringBuilder sb = new StringBuilder();
                try {
                    URL url = new URL("http://"+ip.val+":8080/test/AppStoreSearch");
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("POST");
                    con.setDoInput(true);
                    con.setDoOutput(true);
                    con.setRequestProperty("Content-Type", "text/plain;charset=UTF-8");
                    con.connect();
                    if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        check = con.getHeaderField("success");
                        BufferedReader in = new BufferedReader(
                                new InputStreamReader(
                                        con.getInputStream()));
                        String str;
                        while ((str = in.readLine()) != null) {
                            sb.append(str);
                        }
                    }
                    con.disconnect();
                } catch (MalformedURLException ex) {
                    ex.printStackTrace();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                return sb.toString();
            }

            @Override
            protected void onPostExecute(String sb) {
                if (check != null) {
                    if (check.equals("true")) {
                        final Vector<store> stores = new Vector<store>();
                        JSONArray storearray = null;
                        try {
                            storearray = new JSONArray(sb);
                            for (int i = 0; i < storearray.length(); i++) {
                                JSONObject current = storearray.getJSONObject(i);
                                store newstore = new store(current.getString("name"), current.getString("timings"), current.getString("level"), current.getString("contacts"));
                                stores.add(newstore);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        int resId = R.anim.layoutfall;
                        LinearLayoutManager man = new LinearLayoutManager(v.getContext());
                        RecyclerView recyclerView = (RecyclerView) v.findViewById(R.id.recyclerView);
                        DividerItemDecoration div = new DividerItemDecoration(recyclerView.getContext(),
                                man.getOrientation());
                        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(v.getContext(), resId);
                        recyclerView.setLayoutAnimation(animation);
                        recyclerView.addItemDecoration(div);
                        final storeadapter adapter = new storeadapter(stores,v.getContext());
                        recyclerView.setHasFixedSize(true);
                        recyclerView.setLayoutManager(man);
                        recyclerView.setAdapter(adapter);
                        EditText search = v.findViewById(R.id.search);
                        search.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {

                            }

                            @Override
                            public void afterTextChanged(Editable s) {
                                filter(s.toString());
                            }

                            void filter(String text){
                                Vector<store> temp = new Vector<store>();
                                for(store d: stores){
                                    if(d.name.toLowerCase().contains(text)){
                                        temp.add(d);
                                    }
                                }
                                adapter.updateList(temp);
                            }
                        });

                    } else if (check.equals("false")) {
                        int duration = Toast.LENGTH_LONG;
                        Toast.makeText(v.getContext(), "Server Response Empty", duration).show();
                    }
                } else {
                    int duration = Toast.LENGTH_LONG;
                    Toast.makeText(v.getContext(), "No Server Response", duration).show();
                }
            }
        }
        new storefetch().execute();
    }
}
