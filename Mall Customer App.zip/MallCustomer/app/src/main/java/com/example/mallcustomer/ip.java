package com.example.mallcustomer;

public class ip {
    public static String val= "192.168.0.103";
}
