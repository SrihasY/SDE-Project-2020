package com.example.mallcustomer;

public class event {
    protected String id, name, desc, datetime, venue, end;

    public event(String i, String n, String desc, String datetime, String venue, String end) {
        this.id = i;
        this.name = n;
        this.desc = desc;
        this.datetime = datetime;
        this.venue = venue;
        this.end = end;
    }
}