package com.example.mallcustomer;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Vector;

public class storeoffers extends BottomSheetDialogFragment {
    String storename;
    public storeoffers(String storename){
        this.storename=storename;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(STYLE_NORMAL,R.style.Theme_MaterialComponents_BottomSheetDialog);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        getDialog().setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                BottomSheetDialog d = (BottomSheetDialog) dialog;
                View bottomSheetInternal = d.findViewById(com.google.android.material.R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheetInternal).setState(BottomSheetBehavior.STATE_EXPANDED);
            }
        });
        return inflater.inflate(R.layout.fragment_storeoffers, container, false);
    }

    @Override
    public void onViewCreated(@NonNull final View view, @Nullable Bundle savedInstanceState) {
        TextView storename = view.findViewById(R.id.storenameoff);
        final String name=this.storename;
        storename.setText(name);
        class offerfetch extends AsyncTask<Void, Void, String> {
            String result;
            private String check;

            @Override
            protected String doInBackground(Void... voids) {
                StringBuilder sb = new StringBuilder();
                try {
                    URL url = new URL("http://"+ip.val+":8080/test/AppOffers");
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("POST");
                    con.setDoInput(true);
                    con.setDoOutput(true);
                    con.setRequestProperty("Content-Type", "text/plain;charset=UTF-8");
                    con.setRequestProperty("storename", name);
                    con.connect();
                    if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        check = con.getHeaderField("success");
                        BufferedReader in = new BufferedReader(
                                new InputStreamReader(
                                        con.getInputStream()));
                        String str;
                        while ((str = in.readLine()) != null) {
                            sb.append(str);
                        }
                    }
                    con.disconnect();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                return sb.toString();
            }

            @Override
            protected void onPostExecute(String sb) {
                final Vector<String> offers = new Vector<String>();
                if (check != null) {
                    if (check.equals("true")) {
                        JSONArray storearray = null;
                        try {
                            storearray = new JSONArray(sb);
                            for (int i = 0; i < storearray.length(); i++) {
                                String newoffer= (String) storearray.get(i);
                                offers.add(newoffer);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        LinearLayoutManager man = new LinearLayoutManager(view.getContext());
                        RecyclerView recyclerView = view.findViewById(R.id.offrecycle);
                        final offadapter adapter = new offadapter(offers,view.getContext());
                        recyclerView.setHasFixedSize(true);
                        recyclerView.setLayoutManager(man);
                        recyclerView.setAdapter(adapter);
                    } else if (check.equals("false")) {

                    }
                } else {
                    int duration = Toast.LENGTH_LONG;
                    Toast.makeText(view.getContext(), "No Server Response", duration).show();
                }
            }
        }
        new offerfetch().execute();

        super.onViewCreated(view, savedInstanceState);
    }
}
