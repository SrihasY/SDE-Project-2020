package com.example.mallcustomer;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;


import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class storeinfo extends BottomSheetDialogFragment {
    store s;
    public storeinfo(store s){
        this.s=s;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(STYLE_NORMAL,R.style.Theme_MaterialComponents_BottomSheetDialog);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        getDialog().setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                BottomSheetDialog d = (BottomSheetDialog) dialog;
                View bottomSheetInternal = d.findViewById(com.google.android.material.R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheetInternal).setState(BottomSheetBehavior.STATE_EXPANDED);
            }
        });
        return inflater.inflate(R.layout.storeinfo, container, false);
    }

    @Override
    public void onViewCreated(@NonNull final View view, @Nullable Bundle savedInstanceState) {
        TextView title =  view.findViewById(R.id.storenameoff);
        TextView level = view.findViewById(R.id.level);
        TextView timings = view.findViewById(R.id.timings);
        TextView contacts = view.findViewById(R.id.contacts);
        Button itemview= view.findViewById(R.id.itemview);
        title.setText(s.name);
        level.setText("Level: "+s.level);
        timings.setText("Timings: "+s.timings);
        contacts.setText("Contacts: "+s.contacts);
        itemview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Intent checkitems = new Intent(view.getContext(),viewitems.class);
            checkitems.putExtra("storename", s.name);
            startActivity(checkitems);
            }
        });
        super.onViewCreated(view, savedInstanceState);
    }
}
