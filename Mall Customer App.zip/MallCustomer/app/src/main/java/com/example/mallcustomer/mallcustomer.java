package com.example.mallcustomer;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Vector;

public class mallcustomer {
    protected String username;
    protected String password;

    public void getdetails(Context context){
        try {
            String name="userdata.txt";
            String text="";
            String yourFilePath = context.getFilesDir() + "/" + name;
            File yourFile = new File(yourFilePath);
            if(!yourFile.exists())
            {
                yourFile.createNewFile();
            }
            InputStream inputStream = new FileInputStream(yourFile);
            StringBuilder stringBuilder = new StringBuilder();
            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString = "";
                while ((receiveString = bufferedReader.readLine()) != null){
                    stringBuilder.append(receiveString);
                    stringBuilder.append(",");
                }
                inputStream.close();
                text = stringBuilder.toString();
            }
            String[] arr= text.split(",");
            this.username=arr[0];
            this.password=arr[1];
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean favcheck(Context context, store store)
    {
        boolean flag=false;
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.serializeNulls();
        Gson gson = gsonBuilder.create();
        String text = "";
        try {
            String name="favoritestores.json";
            String yourFilePath = context.getFilesDir() + "/" + name;
            File yourFile = new File(yourFilePath);
            if(!yourFile.exists())
            {
                yourFile.createNewFile();
            }
            InputStream inputStream = new FileInputStream(yourFile);
            StringBuilder stringBuilder = new StringBuilder();
            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString = "";
                while ((receiveString = bufferedReader.readLine()) != null){
                    stringBuilder.append(receiveString);
                }
                inputStream.close();
                text = stringBuilder.toString();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(text.equals(""))
            flag=false;
        else{
            Vector<store> favorites = new Vector<store>();
            JSONArray favarray = null;
            try {
                favorites.clear();
                favarray = new JSONArray(text);
                for (int i = 0; i < favarray.length(); i++) {
                    JSONObject current = favarray.getJSONObject(i);
                    store newstore = new store(current.getString("name"), current.getString("timings"), current.getString("level"), current.getString("contacts"));
                    if((store.name).equals(newstore.name)) {
                        flag = true;
                    }
                    favorites.add(newstore);
                }
                String send = gson.toJson(favorites);
                try {
                    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput("favoritestores.json", Context.MODE_PRIVATE));
                    outputStreamWriter.write(send);
                    outputStreamWriter.close();
                }
                catch (IOException e) {
                    Log.e("Exception", "File write failed: " + e.toString());
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return flag;
    }

    public boolean favupdate(Context context, store store){
        boolean flag=false;
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.serializeNulls();
        Gson gson = gsonBuilder.create();
        String text = "";
        try {
            String name="favoritestores.json";
            String yourFilePath = context.getFilesDir() + "/" + name;
            File yourFile = new File(yourFilePath);
            if(!yourFile.exists())
            {
                yourFile.createNewFile();
            }
            InputStream inputStream = new FileInputStream(yourFile);
            StringBuilder stringBuilder = new StringBuilder();
            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString = "";
                while ((receiveString = bufferedReader.readLine()) != null){
                    stringBuilder.append(receiveString);
                }
                inputStream.close();
                text = stringBuilder.toString();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        Vector<store> favorites = new Vector<store>();
        favorites.clear();
        if(text.equals(""))
            flag=false;
        else{
            JSONArray favarray = null;
            try {
                favarray = new JSONArray(text);
                for (int i = 0; i < favarray.length(); i++) {
                    JSONObject current = favarray.getJSONObject(i);
                    store newstore = new store(current.getString("name"), current.getString("timings"), current.getString("level"), current.getString("contacts"));
                    if((store.name).equals(newstore.name)) {
                        flag = true;
                    } else{
                        favorites.add(newstore);
                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        if(!flag)
        {
            favorites.add(store);
        }
        String send = gson.toJson(favorites);
        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput("favoritestores.json", Context.MODE_PRIVATE));
            outputStreamWriter.write(send);
            outputStreamWriter.close();
        }
        catch (IOException e) {
            Log.e("Exception", "File write failed: " + e.toString());
        }
        return flag;
    }

    public Vector<store> getfav(Context context){
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.serializeNulls();
        Gson gson = gsonBuilder.create();
        String text = "";
        try {
            String name="favoritestores.json";
            String yourFilePath = context.getFilesDir() + "/" + name;
            File yourFile = new File(yourFilePath);
            if(!yourFile.exists())
            {
                yourFile.createNewFile();
            }
            InputStream inputStream = new FileInputStream(yourFile);
            StringBuilder stringBuilder = new StringBuilder();
            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString = "";
                while ((receiveString = bufferedReader.readLine()) != null){
                    stringBuilder.append(receiveString);
                }
                inputStream.close();
                text = stringBuilder.toString();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        Vector<store> favorites = new Vector<store>();
        try {
            favorites.clear();
            JSONArray favarray = new JSONArray(text);
            for (int i = 0; i < favarray.length(); i++) {
                JSONObject current = favarray.getJSONObject(i);
                store newstore = new store(current.getString("name"), current.getString("timings"), current.getString("level"), current.getString("contacts"));
                favorites.add(newstore);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return favorites;
    }

}
