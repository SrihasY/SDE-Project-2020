package com.example.mallcustomer;

import android.content.Context;
import android.util.Log;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Serializable;

public class store implements Serializable {
    protected String name;
    protected String timings;
    protected String level;
    protected String contacts;
    public store(String n, String t, String l, String c)
    {
        this.name=n;
        this.timings=t;
        this.level=l;
        this.contacts=c;
    }

    @Override
    public String toString(){
        return name;
    }

}
