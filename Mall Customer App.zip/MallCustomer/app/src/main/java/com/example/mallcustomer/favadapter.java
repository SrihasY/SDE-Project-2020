package com.example.mallcustomer;

import android.content.Context;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Vector;



public class favadapter extends RecyclerView.Adapter<favadapter.ViewHolder>{
    Vector<store> favorites;
    Context context;
    public favadapter(Vector<store> favorites,Context context) {
        this.favorites=favorites;
        this.context=context;
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.favcard, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        final store current = favorites.get(position);
        final String storename = current.name;
        holder.store_name.setText(current.name);
        holder.level.setText("Level: "+current.level);
        holder.timings.setText("Timings: "+current.timings);
        holder.contacts.setText("Contacts: "+current.contacts);
        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BottomSheetDialogFragment bottomSheetDialogFragment = new storeoffers(storename);
                bottomSheetDialogFragment.show(((FragmentActivity)context).getSupportFragmentManager(), bottomSheetDialogFragment.getTag());
            }
        });

    }


    @Override
    public int getItemCount() {
        return favorites.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView store_name;
        public CardView card;
        public  ConstraintLayout base;
        public TextView level;
        public TextView timings;
        public TextView contacts;
        public ViewHolder(View itemView) {
            super(itemView);
            this.card = itemView.findViewById(R.id.card);
            this.store_name =  itemView.findViewById(R.id.favstorename);
            this.base= itemView.findViewById(R.id.base);
            this.level= itemView.findViewById(R.id.levelcard);
            this.timings= itemView.findViewById(R.id.timingscard);
            this.contacts= itemView.findViewById(R.id.contactscard);
        }
    }
}