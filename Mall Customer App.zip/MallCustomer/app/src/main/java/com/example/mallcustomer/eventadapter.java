package com.example.mallcustomer;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Vector;



public class eventadapter extends RecyclerView.Adapter<eventadapter.ViewHolder> {
    Vector<event> events;
    Context context;
    public eventadapter(Vector<event> events,Context context) {
        this.events = events;
        this.context=context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.event, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final event current = events.get(position);
        holder.name.setText(current.name);
        holder.datetime.setText(current.datetime);
        holder.venue.setText(current.venue);
        holder.lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext(), R.style.Theme_MaterialComponents_Dialog);
                ViewGroup viewGroup = v.findViewById(android.R.id.content);
                final View dialogView = LayoutInflater.from(v.getContext()).inflate(R.layout.eventdialog, viewGroup, false);
                builder.setView(dialogView);
                TextView description = dialogView.findViewById(R.id.evdesc);
                TextView end= dialogView.findViewById(R.id.evend);
                Button ok = dialogView.findViewById(R.id.okevent);
                description.setText("Description: "+current.desc);
                end.setText("End Date/Time: "+current.end);
                final AlertDialog alertDialog = builder.create();
                alertDialog.show();
                ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.dismiss();
                    }
                });
            }
        });
    }


    @Override
    public int getItemCount() {
        return events.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView name;
        public TextView datetime;
        public TextView venue;
        public ConstraintLayout lay;
        public ViewHolder(View itemView) {
            super(itemView);
            this.name = itemView.findViewById(R.id.name);
            this.datetime = itemView.findViewById(R.id.datetime);
            this.venue = itemView.findViewById(R.id.venue);
            this.lay = itemView.findViewById(R.id.eventlay);
        }
    }
}