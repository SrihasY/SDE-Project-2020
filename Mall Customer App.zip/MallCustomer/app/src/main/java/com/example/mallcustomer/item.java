package com.example.mallcustomer;

public class item {
    protected String id,name,stock;
    public item(String id, String name, String stock){
        this.id=id;
        this.name=name;
        this.stock=stock;
    }
}
