package com.example.mallcustomer;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        final Button login = findViewById(R.id.login);
        try {
            String name="userdata.txt";
            String text="";
            String yourFilePath = getApplicationContext().getFilesDir() + "/" + name;
            File yourFile = new File(yourFilePath);
            if(!yourFile.exists())
            {
                yourFile.createNewFile();
            }
            InputStream inputStream = new FileInputStream(yourFile);
            StringBuilder stringBuilder = new StringBuilder();
            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString = "";
                while ((receiveString = bufferedReader.readLine()) != null){
                    stringBuilder.append(receiveString);
                }
                inputStream.close();
                if(stringBuilder.toString()!=null)
                {
                    text=stringBuilder.toString();
                }
            }
            if(text!="")
            {
                Intent open = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(open);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                class login extends AsyncTask<Void, Void, String> {
                    String result;
                    private String check;
                    EditText user = findViewById(R.id.username);
                    EditText pass = findViewById(R.id.password);
                    String username= user.getText().toString();
                    String password= pass.getText().toString();
                    @Override
                    protected String doInBackground(Void... voids) {
                        StringBuilder sb = new StringBuilder();
                        try {
                            URL url = new URL("http://"+ip.val+":8080/test/AppLoginResponse");
                            HttpURLConnection con = (HttpURLConnection) url.openConnection();
                            con.setRequestMethod("POST");
                            con.setDoInput(true);
                            con.setDoOutput(true);
                            con.setRequestProperty("Content-Type", "text/plain;charset=UTF-8");
                            con.setRequestProperty("username", username);
                            con.setRequestProperty("password", password);
                            con.connect();
                            if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
                                check = con.getHeaderField("success");
                            }
                            con.disconnect();
                        } catch (MalformedURLException ex) {
                            ex.printStackTrace();
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                        return check;
                    }

                    @Override
                    protected void onPostExecute(String sb) {
                        if (check != null) {
                            if(check.equals("true"))
                            {
                                /*int duration = Toast.LENGTH_SHORT;
                                Toast.makeText(login.getContext(), "Login successful!", duration).show();*/
                                try {
                                    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(user.getContext().openFileOutput("userdata.txt", Context.MODE_PRIVATE));
                                    outputStreamWriter.write(username+'\n'+password);
                                    outputStreamWriter.close();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                Intent open = new Intent(login.getContext(),MainActivity.class);
                                startActivity(open);
                            }
                            else if(check.equals("false"))
                            {
                                int duration = Toast.LENGTH_SHORT;
                                Toast.makeText(login.getContext(), "Login unsuccessful. Please check login information and try again.", duration).show();
                            }
                        } else {
                            int duration = Toast.LENGTH_SHORT;
                            Toast.makeText(login.getContext(), "No Server Response", duration).show();
                        }
                    }
                }
                new login().execute();
            }
        });


        final Button register=findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent open = new Intent(register.getContext(),register.class);
                startActivity(open);
            }
        });

    }
}

                    /*BufferedReader in = new BufferedReader(
                            new InputStreamReader(
                                    con.getInputStream()));
                    String str;
                    while ((str = in.readLine()) != null) {
                        sb.append(str);
                    }
                    */