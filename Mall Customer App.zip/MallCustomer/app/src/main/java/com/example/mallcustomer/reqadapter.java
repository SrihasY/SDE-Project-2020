package com.example.mallcustomer;


import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;


import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.Vector;

import static androidx.core.content.ContextCompat.startActivity;


public class reqadapter extends RecyclerView.Adapter<reqadapter.ViewHolder> {
    Vector<request> requests;
    Context context;
    public reqadapter(Vector<request> requests,Context context) {
        this.requests = requests;
        this.context=context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.request, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final request current = requests.get(position);
        holder.rname.setText(current.name);
        holder.rstore.setText(current.store);
        holder.rstatus.setText(current.status);
        holder.lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext(), R.style.Theme_MaterialComponents_Dialog);
                ViewGroup viewGroup = view.findViewById(android.R.id.content);
                final View dialogView = LayoutInflater.from(view.getContext()).inflate(R.layout.reqdialog, viewGroup, false);
                builder.setView(dialogView);
                TextView id = dialogView.findViewById(R.id.reqid);
                TextView desc= dialogView.findViewById(R.id.reqdesc);
                Button ok = dialogView.findViewById(R.id.okreq);
                id.setText("Request ID: "+current.id);
                desc.setText("Request Description: "+current.description);
                final AlertDialog alertDialog = builder.create();
                alertDialog.show();
                ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.dismiss();
                    }
                });
            }
        });
    }


    @Override
    public int getItemCount() {
        return requests.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView rname;
        public TextView rstore;
        public TextView rstatus;
        public ConstraintLayout lay;
        public ViewHolder(View itemView) {
            super(itemView);
            this.rname = itemView.findViewById(R.id.rname);
            this.rstore = itemView.findViewById(R.id.rstore);
            this.rstatus = itemView.findViewById(R.id.rstatus);
            this.lay = itemView.findViewById(R.id.request);
        }
    }
}